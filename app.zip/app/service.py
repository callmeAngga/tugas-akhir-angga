from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pvlib
from pvlib.location import Location


# ---------------------------------------------------------------------------
# Path & Konstanta
# ---------------------------------------------------------------------------
APP_DIR = Path(__file__).resolve().parent
REPO_DIR = APP_DIR.parent
ML_DIR = REPO_DIR / "ml"
DATASET_FILE = ML_DIR / "data" / "processed" / "features_dataset.csv"
MODELS_DIR = ML_DIR / "models"
RESULTS_DIR = ML_DIR / "data" / "results"

# Tahun data yang tersedia untuk baseline multi-tahun
ALL_YEARS = [2021, 2022, 2023, 2024, 2025]

# Urutan fitur — HARUS sama persis dengan saat training (skenario METEO)
METEO_FEATURES = [
    "lat", "lon", "month", "day_of_year",
    "month_sin", "month_cos", "doy_sin", "doy_cos",
    "TEMP", "RH", "PRECIP",
]

# Faktor konversi energi harian (kWh/m²) <-> iradiansi rata-rata (W/m²).
# Asumsi ~10 jam matahari efektif per hari di wilayah tropis Indonesia,
# sehingga: iradiansi_W/m² = energi_kWh * 1000 / 10.
EFFECTIVE_SUN_HOURS = 10.0


# ---------------------------------------------------------------------------
# Basis Data Modul PV
# ---------------------------------------------------------------------------
PV_MODULES = {
    "generic_mono_400W": {"name": "Monocrystalline 400 Wp", "watt": 400, "area_m2": 2.0},
    "generic_mono_550W": {"name": "Monocrystalline 550 Wp", "watt": 550, "area_m2": 2.6},
    "generic_poly_330W": {"name": "Polycrystalline 330 Wp", "watt": 330, "area_m2": 2.0},
}

# Parameter default analisis. Nilai orientasi (tilt/azimuth) di sini hanya
# fallback; nilai yang sebenarnya dipakai berasal dari rekomendasi otomatis
# atau override manual user (lihat recommend_orientation).
DEFAULT_PARAMS = {
    "capex_per_kwp": 15_000_000.0,
    "tarif_rp_kwh": 1_444.70,
    "lifetime_thn": 25,
    "discount_rate": 0.06,
    "degradasi": 0.005,
    "performance_ratio": 0.80,
    "self_consumption": 0.65,
    "opex_rate": 0.01,
    "eskalasi_tarif": 0.03,
    "tilt": 10.0,
    "azimuth": 0.0,
    "albedo": 0.2,
}

# Fraksi atap yang benar-benar bisa dipasangi panel setelah dikurangi
# jarak aman (setback), obstruksi, dan gang pemeliharaan.
USABLE_FRACTION = 0.70


# ---------------------------------------------------------------------------
# Pemilihan Model Terbaik Otomatis
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _select_best_model() -> dict:
    """
    Purpose : Memilih model produksi terbaik secara otomatis, tanpa
              melibatkan user sama sekali.
    Inputs  : File hasil training *_results.json di folder results.
    Outputs : dict {algorithm, test_rmse, estimator, model_file}.
    Workflow: Baca setiap results JSON -> ambil RMSE test skenario METEO ->
              pilih RMSE terendah -> muat file .pkl model tersebut.
    Assump. : Skenario METEO dipakai (bukan FULL), karena FULL memuat
              DNI/DHI yang merupakan komponen sirkular dari GHI. Konsisten
              dengan notebook 06 (perbandingan model).
    Notes   : Di-cache (lru_cache) agar model hanya dimuat sekali per proses.
    """
    candidates = []
    for results_path in RESULTS_DIR.glob("*_results.json"):
        try:
            with open(results_path, encoding="utf-8") as f:
                data = json.load(f)
            algo = data.get("algorithm", results_path.stem.split("_")[0])
            meteo = data["scenarios"]["METEO"]
            rmse = float(meteo["metrics_test"]["RMSE"])
            candidates.append({"algorithm": algo, "rmse": rmse})
        except (KeyError, ValueError, json.JSONDecodeError):
            # Lewati file hasil yang formatnya tidak sesuai
            continue

    if not candidates:
        # Fallback: gunakan LightGBM jika file hasil tidak tersedia
        best = {"algorithm": "lightgbm", "rmse": float("nan")}
    else:
        best = min(candidates, key=lambda c: c["rmse"])

    algo = best["algorithm"]
    model_pkl = MODELS_DIR / f"{algo}_METEO.pkl"
    if not model_pkl.exists():
        raise FileNotFoundError(f"Model terlatih tidak ditemukan: {model_pkl}")

    estimator = joblib.load(model_pkl)

    return {
        "algorithm": algo,
        "test_rmse": best["rmse"],
        "estimator": estimator,
        "model_file": model_pkl.name,
    }


def get_active_model_info() -> dict:
    """Metadata publik model aktif (tanpa objek estimator)."""
    info = _select_best_model()
    return {
        "algorithm": info["algorithm"],
        "test_rmse": info["test_rmse"],
        "model_file": info["model_file"],
    }


# ---------------------------------------------------------------------------
# Loader Data
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _load_dataset() -> pd.DataFrame:
    """Muat dataset fitur (di-cache) dan tambahkan kolom tahun."""
    df = pd.read_csv(DATASET_FILE, parse_dates=["date"])
    df["year"] = df["date"].dt.year
    return df


@lru_cache(maxsize=1)
def get_grids() -> list[dict]:
    """Daftar titik grid training (untuk menampilkan cakupan pada peta)."""
    df = _load_dataset()
    g = (
        df.groupby("location_id")[["lat", "lon"]]
        .first()
        .reset_index()
        .sort_values(["lat", "lon"])
    )
    return [
        {"id": r.location_id, "lat": float(r.lat), "lon": float(r.lon)}
        for r in g.itertuples(index=False)
    ]


def get_modules() -> dict:
    """Kembalikan basis data modul PV."""
    return PV_MODULES


def _nearest_grid(lat: float, lon: float) -> dict:
    """Cari titik grid meteorologi terdekat (jarak euclidean sederhana)."""
    grids = get_grids()
    return min(grids, key=lambda g: (g["lat"] - lat) ** 2 + (g["lon"] - lon) ** 2)


# ---------------------------------------------------------------------------
# Estimasi Panel / Kapasitas
# ---------------------------------------------------------------------------
def estimate_system(area_m2: float, module_key: str, custom: dict | None = None) -> dict:
    """
    Purpose : Menghitung ukuran sistem PV yang bisa dipasang di atap.
    Inputs  : area_m2 (luas atap), module_key (kunci modul), custom (opsional).
    Outputs : dict {module, usable_area_m2, n_panels, capacity_kwp}.
    Workflow: Luas efektif = area * USABLE_FRACTION -> jumlah panel =
              floor(luas efektif / luas panel) -> kapasitas = n * watt / 1000.
    Assump. : Panel dipasang datar mengikuti bidang atap (packing sederhana).
    """
    if custom:
        module = {"name": "Custom Module", **custom}
    else:
        module = PV_MODULES.get(module_key, PV_MODULES["generic_mono_400W"])

    usable_area = area_m2 * USABLE_FRACTION
    n_panels = int(usable_area / module["area_m2"]) if module["area_m2"] > 0 else 0
    capacity_kwp = n_panels * module["watt"] / 1000.0

    return {
        "module": module,
        "usable_area_m2": round(usable_area, 1),
        "n_panels": n_panels,
        "capacity_kwp": round(capacity_kwp, 2),
    }


# ---------------------------------------------------------------------------
# Inferensi ML NYATA: prediksi GHI seluruh tahun
# ---------------------------------------------------------------------------
def _predict_ghi_all_years(lat: float, lon: float) -> tuple[pd.DataFrame, dict]:
    """
    Purpose : Menjalankan inferensi NYATA memakai model terlatih untuk
              memprediksi GHI harian sepanjang tahun yang tersedia.
    Inputs  : lat, lon koordinat atap user.
    Outputs : (DataFrame[date, year, GHI_pred], dict grid terdekat).
    Workflow: Ambil deret meteorologi dari grid terdekat -> bangun fitur
              METEO (koordinat user + siklus musiman + TEMP/RH/PRECIP) ->
              panggil estimator.predict().
    Assump. : Koordinat memakai lat/lon user, sedangkan variabel meteorologi
              memakai grid terdekat (resolusi data terbatas 40 titik).
    Notes   : GHI diklip minimum 0 (iradiasi tidak boleh negatif).
    """
    grid = _nearest_grid(lat, lon)
    df = _load_dataset()
    site = df[df["location_id"] == grid["id"]].sort_values("date").copy()

    month = site["date"].dt.month
    doy = site["date"].dt.dayofyear

    feats = pd.DataFrame({
        "lat": lat,
        "lon": lon,
        "month": month.values,
        "day_of_year": doy.values,
        "month_sin": np.sin(2 * np.pi * month.values / 12.0),
        "month_cos": np.cos(2 * np.pi * month.values / 12.0),
        "doy_sin": np.sin(2 * np.pi * doy.values / 365.25),
        "doy_cos": np.cos(2 * np.pi * doy.values / 365.25),
        "TEMP": site["TEMP"].values,
        "RH": site["RH"].values,
        "PRECIP": site["PRECIP"].values,
    })[METEO_FEATURES]

    estimator = _select_best_model()["estimator"]
    ghi_pred = estimator.predict(feats)          # <-- INFERENSI MODEL NYATA
    ghi_pred = np.clip(np.asarray(ghi_pred, dtype=float), 0, None)

    result = site[["date", "year"]].copy().reset_index(drop=True)
    result["GHI_pred"] = ghi_pred
    return result, grid


# ---------------------------------------------------------------------------
# Forecasting GHI 2026 (climatology-based future covariates)
# ---------------------------------------------------------------------------
FORECAST_YEAR = 2026


def _forecast_ghi_2026(lat: float, lon: float) -> tuple[pd.DataFrame, dict]:
    """
    Purpose : Meramalkan GHI harian tahun 2026 sebagai basis produksi Year-1,
              KONSISTEN dengan notebook 06 (Tahap 6c). Menggantikan pendekatan
              lama yang memakai rata-rata multi-tahun 2021-2025.
    Inputs  : lat, lon koordinat atap user.
    Outputs : (DataFrame[date, GHI_pred] untuk 2026, dict grid terdekat).
    Workflow: Bangun climatology day-of-year (rata-rata 2021-2025) untuk
              TEMP/RH/PRECIP di grid terdekat -> susun kalender 2026 dengan
              fitur temporal/spasial deterministik + meteo climatology ->
              prediksi GHI 2026 dengan model terlatih (tanpa retraining).
    Assump. : Variabel meteorologi 2026 belum tersedia sehingga diwakili
              rata-rata historis per day-of-year (future covariates).
    Notes   : GHI diklip minimum 0 (iradiasi tidak boleh negatif).
    """
    grid = _nearest_grid(lat, lon)
    df = _load_dataset()
    site = df[df["location_id"] == grid["id"]].copy()
    site["doy"] = site["date"].dt.dayofyear

    # Climatology meteorologi per day-of-year (rata-rata 2021-2025)
    clim = site.groupby("doy")[["TEMP", "RH", "PRECIP"]].mean()
    clim_fallback = clim.mean()

    # Kalender 2026 (non-kabisat, 365 hari)
    dates = pd.date_range(f"{FORECAST_YEAR}-01-01", f"{FORECAST_YEAR}-12-31", freq="D")
    doy = dates.dayofyear.to_numpy()

    def _clim_series(col: str) -> np.ndarray:
        vals = clim[col].reindex(doy).to_numpy()
        return np.where(np.isnan(vals), float(clim_fallback[col]), vals)

    month = dates.month.to_numpy()
    feats = pd.DataFrame({
        "lat": lat,
        "lon": lon,
        "month": month,
        "day_of_year": doy,
        "month_sin": np.sin(2 * np.pi * month / 12.0),
        "month_cos": np.cos(2 * np.pi * month / 12.0),
        "doy_sin": np.sin(2 * np.pi * doy / 365.25),
        "doy_cos": np.cos(2 * np.pi * doy / 365.25),
        "TEMP": _clim_series("TEMP"),
        "RH": _clim_series("RH"),
        "PRECIP": _clim_series("PRECIP"),
    })[METEO_FEATURES]

    estimator = _select_best_model()["estimator"]
    ghi_pred = np.clip(np.asarray(estimator.predict(feats), dtype=float), 0, None)

    result = pd.DataFrame({"date": dates, "GHI_pred": ghi_pred})
    return result, grid


# ---------------------------------------------------------------------------
# Dekomposisi & Transposisi Iradiasi (GHI -> POA)
# ---------------------------------------------------------------------------
def _decompose_day(date, ghi_kwh: float, site: Location) -> dict | None:
    """
    Purpose : Menghitung komponen iradiasi (DNI, DHI, GHI) untuk satu hari,
              bagian yang TIDAK bergantung pada orientasi panel.
    Inputs  : date (tanggal), ghi_kwh (GHI harian), site (Location pvlib).
    Outputs : dict komponen iradiasi + geometri matahari, atau None jika
              malam/GHI nol.
    Workflow: Posisi matahari (NREL SPA) siang hari -> konversi GHI harian ke
              iradiansi W/m² -> indeks kecerahan kt -> fraksi difus Erbs (1982)
              -> pisahkan menjadi DHI dan DNI.
    Assump. : Satu titik waktu representatif (tengah hari lokal) dipakai untuk
              mewakili geometri harian; dis,konsisten dengan resolusi data harian.
    Notes   : Dipisah dari transposisi agar bisa dipakai ulang saat memindai
              banyak sudut tilt (rekomendasi orientasi) tanpa hitung ulang.
    """
    noon = pd.Timestamp(date).replace(hour=12, minute=0)
    times = pd.DatetimeIndex([noon], tz="Asia/Jakarta")

    solpos = site.get_solarposition(times)
    zenith = float(solpos["apparent_zenith"].iloc[0])
    sol_azimuth = float(solpos["azimuth"].iloc[0])

    # Matahari di bawah horizon atau tidak ada iradiasi -> lewati
    if zenith >= 90 or ghi_kwh <= 0:
        return None

    doy = pd.Timestamp(date).dayofyear
    dni_extra = float(pvlib.irradiance.get_extra_radiation(doy))
    cos_z = np.cos(np.radians(zenith))

    ghi_wm2 = ghi_kwh * 1000 / EFFECTIVE_SUN_HOURS
    kt = float(np.clip(ghi_wm2 / (dni_extra * max(cos_z, 0.05)), 0, 1.0))

    # Fraksi difus Erbs (1982)
    if kt <= 0.22:
        kd = 1.0 - 0.09 * kt
    elif kt <= 0.80:
        kd = 0.9511 - 0.1604 * kt + 4.388 * kt**2 - 16.638 * kt**3 + 12.336 * kt**4
    else:
        kd = 0.165

    dhi_wm2 = kd * ghi_wm2
    dni_wm2 = max((ghi_wm2 - dhi_wm2) / max(cos_z, 0.05), 0)

    return {
        "zenith": zenith,
        "sol_azimuth": sol_azimuth,
        "dni_extra": dni_extra,
        "ghi_wm2": ghi_wm2,
        "dhi_wm2": dhi_wm2,
        "dni_wm2": dni_wm2,
    }


def _transpose(comp: dict, tilt: float, azimuth: float, albedo: float) -> float:
    """
    Purpose : Transposisi iradiasi bidang horizontal -> bidang miring panel
              (Plane of Array) untuk satu hari.
    Inputs  : comp (hasil _decompose_day), tilt, azimuth, albedo.
    Outputs : POA harian dalam kWh/m².
    Workflow: Model transposisi Perez (1990) via pvlib.get_total_irradiance,
              lalu konversi kembali iradiansi W/m² -> energi harian kWh/m².
    Assump. : Jika transposisi gagal, fallback ke GHI (POA = GHI).
    """
    try:
        poa = pvlib.irradiance.get_total_irradiance(
            surface_tilt=tilt, surface_azimuth=azimuth,
            solar_zenith=comp["zenith"], solar_azimuth=comp["sol_azimuth"],
            dni=comp["dni_wm2"], ghi=comp["ghi_wm2"], dhi=comp["dhi_wm2"],
            dni_extra=comp["dni_extra"], model="perez", albedo=albedo,
        )
        poa_wm2 = max(float(np.asarray(poa["poa_global"]).item()), 0)
    except Exception:
        poa_wm2 = comp["ghi_wm2"]

    return poa_wm2 * EFFECTIVE_SUN_HOURS / 1000.0


def _poa_daily(dates, ghi_daily, lat, lon, tilt, azimuth, albedo) -> np.ndarray:
    """
    Purpose : Menghitung deret POA harian untuk satu tahun/periode.
    Inputs  : dates, ghi_daily, koordinat, tilt, azimuth, albedo.
    Outputs : np.ndarray POA harian (kWh/m²).
    Workflow: Untuk tiap hari: dekomposisi (Erbs) lalu transposisi (Perez).
    """
    site = Location(lat, lon, tz="Asia/Jakarta")
    out = []
    for date, ghi_kwh in zip(dates, ghi_daily):
        comp = _decompose_day(date, ghi_kwh, site)
        if comp is None:
            out.append(0.0)
            continue
        out.append(_transpose(comp, tilt, azimuth, albedo))
    return np.array(out)


# ---------------------------------------------------------------------------
# Rekomendasi Orientasi Panel (Tilt & Azimuth) — berbasis fisika, bukan hardcode
# ---------------------------------------------------------------------------
def recommend_orientation(lat: float, lon: float, albedo: float = 0.2) -> dict:
    """
    Purpose : Merekomendasikan sudut tilt dan azimuth optimal secara otomatis
              sehingga user tidak perlu memahami rekayasa fotovoltaik.
    Inputs  : lat, lon koordinat atap; albedo permukaan sekitar.
    Outputs : dict {tilt, azimuth, azimuth_label, method, poa_annual_kwh_m2}.
    Workflow:
        1. Azimuth ditentukan oleh belahan bumi (panel menghadap ekuator):
           - Belahan selatan (lat < 0) -> menghadap Utara  -> azimuth 0°.
           - Belahan utara   (lat >= 0) -> menghadap Selatan -> azimuth 180°.
        2. Tilt dipilih dengan STRATEGI pvlib: memindai kandidat sudut tilt
           lalu memilih tilt yang MEMAKSIMALKAN total POA tahunan, dihitung
           dari GHI hasil prediksi model NYATA + transposisi Perez.
    Assump. : Menggunakan satu tahun representatif (tengah rentang data) demi
              respons cepat; dekomposisi harian dihitung sekali lalu dipakai
              ulang untuk semua kandidat tilt.
    Notes   : Pendekatan ini akademis dan TIDAK di-hardcode — tilt optimal
              muncul dari maksimisasi iradiasi bidang panel, bukan angka tetap.
              Rentang pindai 0–30° sesuai wilayah lintang rendah (tropis).
    """
    # 1) Azimuth menghadap ekuator berdasarkan belahan bumi
    if lat < 0:
        azimuth = 0.0
        azimuth_label = "Utara (menghadap ekuator)"
    else:
        azimuth = 180.0
        azimuth_label = "Selatan (menghadap ekuator)"

    # 2) Pindai tilt untuk memaksimalkan POA tahunan (strategi pvlib)
    ghi_data, _ = _predict_ghi_all_years(lat, lon)
    mid_year = ALL_YEARS[len(ALL_YEARS) // 2]
    yd = ghi_data[ghi_data["year"] == mid_year]
    if len(yd) == 0:
        yd = ghi_data

    site = Location(lat, lon, tz="Asia/Jakarta")
    # Dekomposisi harian dihitung sekali (tidak bergantung tilt)
    comps = [
        _decompose_day(d, g, site)
        for d, g in zip(yd["date"].values, yd["GHI_pred"].values)
    ]

    candidate_tilts = range(0, 31, 2)
    best_tilt, best_poa = 0, -1.0
    for tilt in candidate_tilts:
        poa_annual = sum(
            _transpose(c, float(tilt), azimuth, albedo)
            for c in comps if c is not None
        )
        if poa_annual > best_poa:
            best_poa, best_tilt = poa_annual, tilt

    return {
        "tilt": float(best_tilt),
        "azimuth": azimuth,
        "azimuth_label": azimuth_label,
        "method": "POA-maximizing scan (Perez) + equator-facing azimuth",
        "poa_annual_kwh_m2": round(best_poa, 1),
    }


# ---------------------------------------------------------------------------
# Net Present Value (satu-satunya indikator ekonomi yang ditampilkan)
# ---------------------------------------------------------------------------
def _npv(rate: float, cashflows: np.ndarray) -> float:
    """NPV: jumlah arus kas terdiskonto pada tingkat diskonto tertentu."""
    cf = np.asarray(cashflows, dtype=float)
    t = np.arange(len(cf))
    return float(np.sum(cf / (1 + rate) ** t))


# ---------------------------------------------------------------------------
# Pipeline Analisis Utama
# ---------------------------------------------------------------------------
def run_analysis(lat: float, lon: float, params: dict) -> dict:
    """
    Purpose : Menjalankan seluruh pipeline analisis kelayakan PV atap.
    Inputs  : lat, lon; params (kapasitas, ekonomi, tilt, azimuth, dll).
    Outputs : dict terstruktur berisi lokasi, sistem, energi (GHI/AEP),
              dan NPV. Hanya NPV & AEP sebagai indikator hasil.
    Workflow: (1) forecast GHI 2026 (climatology-based future covariates) ->
              (2) POA + AEP tahun 2026 sebagai Year-1 -> (3) TEA -> NPV.
    Assump. : Baseline Year-1 = forecast 2026 (KONSISTEN dengan notebook 06).
              AEP = kapasitas * POA * performance ratio.
    """
    p = {**DEFAULT_PARAMS, **params}

    capacity = float(p["capacity_kwp"])
    capex_total = capacity * float(p["capex_per_kwp"])
    opex_annual = float(p["opex_rate"]) * capex_total
    tariff = float(p["tarif_rp_kwh"])
    lifetime = int(p["lifetime_thn"])
    discount = float(p["discount_rate"])
    degrad = float(p["degradasi"])
    pr = float(p["performance_ratio"])
    self_cons = float(p["self_consumption"])
    escalation = float(p["eskalasi_tarif"])
    tilt = float(p["tilt"])
    azimuth_val = float(p["azimuth"])
    albedo = float(p["albedo"])

    model_info = _select_best_model()

    # 1) Forecast GHI 2026 (climatology-based future covariates)
    forecast, grid = _forecast_ghi_2026(lat, lon)

    # 2) Transposisi POA + AEP tahun 2026 (basis Year-1)
    poa_daily = _poa_daily(
        forecast["date"].values, forecast["GHI_pred"].values,
        lat, lon, tilt, azimuth_val, albedo,
    )
    ghi_annual = float(forecast["GHI_pred"].sum())
    poa_annual = float(poa_daily.sum())
    aep_year1 = capacity * poa_annual * pr

    # 2b) Profil GHI harian 2026 untuk grafik (forecast, bukan rata-rata historis)
    ghi_profile_values = [round(float(v), 3) for v in forecast["GHI_pred"].to_numpy()]
    ghi_profile_labels = [d.strftime("%Y-%m-%d") for d in forecast["date"]]

    # 3) Baseline Year-1 = forecast 2026
    e_year1 = aep_year1
    specific_yield = e_year1 / capacity if capacity > 0 else 0

    # 4) TEA -> hanya NPV
    years_arr = np.arange(1, lifetime + 1)
    energy = e_year1 * (1 - degrad) ** (years_arr - 1)
    tariff_year = tariff * (1 + escalation) ** (years_arr - 1)
    savings = energy * self_cons * tariff_year
    net_cf = savings - opex_annual
    cashflows = np.concatenate([[-capex_total], net_cf])
    project_npv = _npv(discount, cashflows)

    return {
        "algorithm": model_info["algorithm"].upper(),
        "model_file": model_info["model_file"],
        "params": p,
        "capex_total": capex_total,
        "lokasi": {
            "lat": lat, "lon": lon,
            "grid_id": grid["id"],
            "area_m2": round(float(p.get("area_m2", 0)), 1),
            "usable_area_m2": round(float(p.get("usable_area_m2", 0)), 1),
        },
        "orientasi": {
            "tilt": round(tilt, 1),
            "azimuth": round(azimuth_val, 1),
        },
        "pv_module": p.get("pv_module_name", "Custom"),
        "n_panels": int(p.get("n_panels", 0)),
        "capacity_kwp": round(capacity, 2),
        "energi": {
            "ghi_annual_kwh_m2": round(ghi_annual, 1),
            "aep_kwh": round(e_year1, 0),
            "specific_yield_kwh_kwp": round(specific_yield, 0),
        },
        "ghi_profile": {
            "labels": ghi_profile_labels,
            "values": ghi_profile_values,
            "annual_kwh_m2": round(ghi_annual, 1),
        },
        "npv": round(project_npv, 0),
        "layak": bool(project_npv > 0),
    }
